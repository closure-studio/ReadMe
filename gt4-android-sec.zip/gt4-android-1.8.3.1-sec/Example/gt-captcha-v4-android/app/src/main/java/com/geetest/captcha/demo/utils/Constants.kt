package com.geetest.captcha.demo.utils

object Constants {
    const val TAG = "Captcha_Demo"
}
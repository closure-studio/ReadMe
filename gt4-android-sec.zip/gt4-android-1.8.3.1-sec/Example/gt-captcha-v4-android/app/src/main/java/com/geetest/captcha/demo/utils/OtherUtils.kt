package com.geetest.captcha.demo.utils

import android.content.Context
import android.content.res.Configuration
import kotlin.math.floor
import kotlin.math.round

object OtherUtils {

    fun isDarkMode(context: Context): Boolean {
        return (context.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
    }

    /**
     * rgba颜色字符串转化为16进制颜色字符串
     * @param rgba rgba颜色字符串
     * @returns 16进制颜色字符串
     */
    fun rgbaToHex(rgba: String): String {
        val arr = parseRgbaColor(rgba)
        return toHexString(arr)
    }

    /**
     * 转化为16进制颜色字符串
     */
    fun toHexString(arr: MutableList<String>): String {
        val result = if (arr.size >= 4) {
            String.format(
                "#%02x%02x%02x%02x",
                arr[0].toInt(),
                arr[1].toInt(),
                arr[2].toInt(),
                floor(arr[3].toFloat() * 255).toInt()
            )
        } else {
            String.format(
                "#%02x%02x%02x", arr[0].toInt(), arr[1].toInt(), arr[2].toInt()
            )
        }
        return result
    }

    /**
     * 颜色字符串解析为颜色对象
     * @param color 颜色字符串
     * @returns IColorObj
     */
//    fun parseColorString(color: String) {
//        if (color.startsWith('#')) {
//            return parseHexColor(color)
//        } else if (color.startsWith('rgb')) {
//            return parseRgbaColor(color)
//        } else if (color === 'transparent') {
//            return parseHexColor('#00000000')
//        }
//    }
//
    /**
     * rgba颜色字符串解析为颜色对象
     * @param color 颜色字符串
     * @returns IColorObj
     */
    fun parseRgbaColor(color: String): MutableList<String> {
//        val regex =
//            "^rgba?\\((\\d+),\\s*(\\d+),\\s*(\\d+)(?:,\\s*(\\d+(?:\\.\\d+)?))?\\)$".toRegex()
//        val matchResults = regex.find(color)
//        return matchResults?.groupValues ?: mutableListOf()
        val result = "\\d+(\\.\\d)?".toRegex().findAll(color)
        val list = mutableListOf<String>()
        for (value in result) {
            list.add(value.value)
        }
        return list
    }

    fun hexToRgba(hexColor: String): String {
        val result = hexToRgbaArray(hexColor.replace("#", ""), 2)
        return "rgba(${result.joinToString()})"
    }

    /**
     * 将字符串按照指定长度分割成字符串数组
     *
     * @param src
     * @param length
     * @return
     */
    fun hexToRgbaArray(src: String?, length: Int): Array<String?> {
        //检查参数是否合法
        if (length <= 0) {
            return emptyArray()
        }
        val n = src?.length?.div(length) //获取整个字符串可以被切割成字符子串的个数
        n?.let {
            val split = arrayOfNulls<String>(it)
            for (i in 0 until it) {
                split[i] =
                    if (i < it - 1) "${src.substring(i * length, (i + 1) * length).toInt(16)}"
                    else "%.1f".format(src.substring(0, length).toInt(16) / 255f)

//                if (i == 0) split[it - 1] = "%.1f".format(src.substring(0, length).toInt(16)/255f)
//                else split[i - 1] =
//                    src.substring(i.times(length), (i + 1).times(length)).toInt(16)
//                else split[i - 1] = src.substring(i.times(length)).toInt(16)
            }
            return split
        }
        return emptyArray()
    }
}
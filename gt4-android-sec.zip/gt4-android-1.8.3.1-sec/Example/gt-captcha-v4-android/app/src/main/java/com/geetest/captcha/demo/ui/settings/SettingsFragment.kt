package com.geetest.captcha.demo.ui.settings

import android.app.Activity
import android.content.SharedPreferences
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.WindowInsets
import android.view.WindowInsetsController
import androidx.navigation.Navigation
import androidx.preference.EditTextPreference
import androidx.preference.PreferenceFragmentCompat
import com.geetest.captcha.demo.MainActivity
import com.geetest.captcha.demo.R


class SettingsFragment : PreferenceFragmentCompat(),
    SharedPreferences.OnSharedPreferenceChangeListener {

    private var textPreference: EditTextPreference? = null

    override fun onCreatePreferences(savedInstanceState: Bundle?, rootKey: String?) {
        setPreferencesFromResource(R.xml.root_preferences, rootKey)
        textPreference = findPreference("input_language")
        textPreference?.isVisible = checkLanguageCustom(preferenceManager.sharedPreferences)
    }

    override fun onResume() {
        super.onResume()
        preferenceManager.sharedPreferences.registerOnSharedPreferenceChangeListener(this)
//        activity?.runOnUiThread {
//            val preferenceGroup: PreferenceGroup? =
//                findPreference("basic_configuration") as PreferenceGroup?
//            val switchPreference = SwitchPreferenceCompat(preferenceManager.context)
//            switchPreference.widgetLayoutResource =
//                androidx.preference.R.layout.preference_widget_switch_compat
//            switchPreference.title = "Test"
//            switchPreference.isChecked = true
//            switchPreference.setDefaultValue(true)
//            switchPreference.isIconSpaceReserved = false
//
//            switchPreference.onPreferenceChangeListener =
//                object : Preference.OnPreferenceChangeListener {
//                    override fun onPreferenceChange(
//                        preference: Preference?,
//                        newValue: Any
//                    ): Boolean {
//                        Toast.makeText(activity, newValue.toString(), Toast.LENGTH_SHORT).show()
//                        return true
//                    }
//                }
//            preferenceGroup?.addPreference(switchPreference)
//        }
    }

    override fun onPause() {
        super.onPause()
        preferenceManager.sharedPreferences.unregisterOnSharedPreferenceChangeListener(this)
    }

    override fun onSharedPreferenceChanged(sharedPreferences: SharedPreferences?, key: String?) {
        when (key) {
            "privatization" -> {
                if (sharedPreferences?.getBoolean(
                        "privatization",
                        requireContext().resources.getBoolean(R.bool.privatization_default)
                    )!!
                ) {
                    val edit = sharedPreferences.edit()
                    val apiServersList =
                        requireContext().resources.getStringArray(R.array.api_server_values)
                    edit.putString("api_servers_list", apiServersList[0])
                    val staticServersList =
                        requireContext().resources.getStringArray(R.array.static_server_values)
                    edit.putString("static_servers_list", staticServersList[0])
                    val htmlList =
                        requireContext().resources.getStringArray(R.array.url_static_values)
                    edit.putString("html_list", htmlList[0])
                    val captchaIdList =
                        requireContext().resources.getStringArray(R.array.settings_captcha_id_values)
                    edit.putString("captcha_id_list", captchaIdList[0])
                    val validateList =
                        requireContext().resources.getStringArray(R.array.validate_values)
                    edit.putString("validate_list", validateList[0])
                    edit.apply()
                } else {
                    val edit = sharedPreferences.edit()
                    val apiServersList =
                        requireContext().resources.getStringArray(R.array.api_server_values)
                    edit.putString("api_servers_list", apiServersList[1])
                    val staticServersList =
                        requireContext().resources.getStringArray(R.array.static_server_values)
                    edit.putString("static_servers_list", staticServersList[1])
                    val htmlList =
                        requireContext().resources.getStringArray(R.array.url_static_values)
                    edit.putString("html_list", htmlList[1])
                    val captchaIdList =
                        requireContext().resources.getStringArray(R.array.settings_captcha_id_values)
                    edit.putString("captcha_id_list", captchaIdList[9])
                    val validateList =
                        requireContext().resources.getStringArray(R.array.validate_values)
                    edit.putString("validate_list", validateList[1])
                    edit.apply()
                }
                if (activity is MainActivity) {
                    val navController = Navigation.findNavController(
                        activity as MainActivity,
                        R.id.nav_host_fragment
                    )
                    navController.navigate(R.id.navigation_settings)
                }
            }
            "fullscreen" -> {
                activity?.let {
                    setFullScreen(
                        it, sharedPreferences?.getBoolean(
                            "fullscreen",
                            requireContext().resources.getBoolean(R.bool.fullscreen_default)
                        )!!
                    )
                }
            }
            "language"->{
                findPreference<EditTextPreference>("input_language")?.isVisible =
                    checkLanguageCustom(sharedPreferences)
            }
        }
    }

    private fun checkLanguageCustom(sharedPreferences: SharedPreferences?) =
        sharedPreferences?.getString(
            "language",
            requireContext().resources.getString(R.string.language_default)
        ).equals("customize")


    private fun setFullScreen(activity: Activity, isFull: Boolean) {
        activity.apply {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                val controller = window.insetsController
                controller?.apply {
                    systemBarsBehavior = if (isFull) {
                        hide(WindowInsets.Type.systemBars())
                        WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                    } else {
                        show(WindowInsets.Type.systemBars())
                        WindowInsetsController.BEHAVIOR_SHOW_BARS_BY_SWIPE
                    }
                }
            } else {
                var uiFlags = if (isFull) {
                    (View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                            or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                            or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                            or View.SYSTEM_UI_FLAG_FULLSCREEN)
                } else {
                    (View.SYSTEM_UI_FLAG_VISIBLE)
                }
                uiFlags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                    uiFlags or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                } else {
                    uiFlags or View.SYSTEM_UI_FLAG_LOW_PROFILE
                }
                window.decorView.systemUiVisibility = uiFlags
                window.decorView.setOnSystemUiVisibilityChangeListener { visibility: Int ->
                    var uiOptions = if (isFull) {
                        (View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                                or View.SYSTEM_UI_FLAG_FULLSCREEN)
                    } else {
                        (View.SYSTEM_UI_FLAG_VISIBLE)
                    }
                    uiOptions = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                        uiOptions or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                    } else {
                        uiOptions or View.SYSTEM_UI_FLAG_LOW_PROFILE
                    }
                    window.decorView.systemUiVisibility = uiOptions
                }
            }
        }
    }
}
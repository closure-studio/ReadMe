package com.geetest.captcha.demo.utils

import android.util.Log
import okhttp3.*
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.logging.HttpLoggingInterceptor

object NetRequestUtils {
    private var okHttpClient: OkHttpClient? = null
    fun requestPost(url: String, postParam: String?): String? {
        val urlBuilder: HttpUrl.Builder = url.toHttpUrlOrNull()!!.newBuilder()
        urlBuilder.addQueryParameter("t", System.currentTimeMillis().toString() + "")
        val mediaType: MediaType = "application/json".toMediaTypeOrNull()!!
        val requestBody = RequestBody.create(mediaType, postParam!!)
        val builder = Request.Builder()
                .post(requestBody)
                .url(urlBuilder.build())
        try {
            val response = okHttpClient!!.newCall(builder.build()).execute()
            return response.body!!.string()
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return null
    }

    fun requestPostByForm(url: String, formBody: FormBody?): String? {
        val urlBuilder: HttpUrl.Builder = url.toHttpUrlOrNull()!!.newBuilder()
        urlBuilder.addQueryParameter("t", System.currentTimeMillis().toString() + "")
        val request = Request.Builder()
                .post(formBody!!)
                .url(urlBuilder.build())
                .build()
        try {
            val response = okHttpClient!!.newCall(request).execute()
            return response.body!!.string()
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return null
    }

    fun requestGet(urlString: String): String? {
        val urlBuilder: HttpUrl.Builder = urlString.toHttpUrlOrNull()!!.newBuilder()
        urlBuilder.addQueryParameter("t", System.currentTimeMillis().toString() + "")
        val request = Request.Builder().url(urlBuilder.build())
                .build()
        try {
            val response = okHttpClient!!.newCall(request).execute()
            return response.body!!.string()
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return null
    }

    private class HttpLogger : HttpLoggingInterceptor.Logger {
        override fun log(message: String) {
            Log.d(Constants.TAG, "Logger: $message")
        }
    }

    init {
        val logInterceptor = HttpLoggingInterceptor(HttpLogger())
        logInterceptor.level = HttpLoggingInterceptor.Level.BODY
        okHttpClient = OkHttpClient.Builder()
                .addNetworkInterceptor(logInterceptor)
                .build()
    }
}
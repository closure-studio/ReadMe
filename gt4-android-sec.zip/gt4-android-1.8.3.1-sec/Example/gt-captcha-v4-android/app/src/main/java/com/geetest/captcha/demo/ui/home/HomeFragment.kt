package com.geetest.captcha.demo.ui.home

import android.app.ProgressDialog
import android.content.Context
import android.content.res.Configuration
import android.os.AsyncTask
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.preference.PreferenceManager
import com.geetest.captcha.GTCaptcha4Client
import com.geetest.captcha.demo.CaptchaUtils
import com.geetest.captcha.demo.R
import com.geetest.captcha.demo.ui.dialog.ToastFragment
import com.geetest.captcha.demo.utils.NetRequestUtils
import okhttp3.FormBody
import org.json.JSONObject
import java.lang.ref.SoftReference

class HomeFragment : Fragment(), View.OnClickListener {
    private var gtCaptcha4Client: GTCaptcha4Client? = null
    private var lastClickTime: Long = 0
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?, savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_home, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val button = view.findViewById<Button>(R.id.btn_captcha)
        button.setOnClickListener(this)
    }

    override fun onClick(v: View) {
        if (System.currentTimeMillis() - lastClickTime < 1000) {
            Log.i(TAG, "click to fast")
            Toast.makeText(context, "click too fast", Toast.LENGTH_SHORT).show()
            return
        }
        lastClickTime = System.currentTimeMillis()
        click()
    }

    private fun click() {
//        val pair = GTCaptcha4Client.isSupportWebView(requireContext())
//        if (!pair.first && pair.second.isNotBlank()) {
//            Toast.makeText(context, pair.second, Toast.LENGTH_SHORT).show()
//            return
//        }
        // val webView = WebView(requireContext())
        // webView.resumeTimers()
        // webView.destroy()
//        WebView(requireContext()).pauseTimers()
        if (isCustomImplLoading()) { // 先弹出loading，为保证loading不被验证码遮挡，需要配置主题移除原生的蒙层
            showCustomLoading()
        }
        gtCaptcha4Client = CaptchaUtils.newGTCaptcha4Client(requireContext())
            .addOnSuccessListener(GTCaptcha4Client.OnSuccessListener { status, response ->
                Log.e(TAG, "onSuccess: $response, ${Looper.getMainLooper() == Looper.myLooper()}")
                //                    Toast.makeText(context, response, Toast.LENGTH_SHORT).show()
                ToastFragment.newInstance(response).show(parentFragmentManager, "toast")
                dismissCustomLoading()
                if (status) {
                    // TODO 开启二次验证
                    // TODO start secondary verification
                    ValidateTask(requireContext()).execute(response)
                } else {
                    // TODO user answer verification error
                    // TODO 用户答案验证错误
                }
            })
            .addOnFailureListener(GTCaptcha4Client.OnFailureListener { error ->
                Log.e(TAG, "onFailure: $error, ${Looper.getMainLooper() == Looper.myLooper()}")
                //                    Toast.makeText(context, error, Toast.LENGTH_SHORT).show()
                ToastFragment.newInstance(error).show(parentFragmentManager, "toast")
                dismissCustomLoading()
            })
            .addOnWebViewShowListener(GTCaptcha4Client.OnWebViewShowListener {
                Log.e(TAG, "onWebViewShow ${Looper.getMainLooper() == Looper.myLooper()}")
                dismissCustomLoading()
            }).verifyWithCaptcha()

        if(PreferenceManager.getDefaultSharedPreferences(context)
                .getBoolean("delay_cancel", resources.getBoolean(R.bool.delay_cancel_default))){
            Handler(Looper.getMainLooper()).postDelayed({
                gtCaptcha4Client?.cancel()
            },2000)
        }
    }

    internal class ValidateTask(context: Context) : AsyncTask<String, Void?, String?>() {
        private val reference: SoftReference<Context?> = SoftReference(context)
        override fun doInBackground(vararg params: String): String? {
            try {
                val preferences = PreferenceManager.getDefaultSharedPreferences(reference.get())
                val formBody = FormBody.Builder()
                val jsonObject = JSONObject(params[0])
                val keys = jsonObject.keys()
                for (item in keys) {
                    formBody.add(item, jsonObject.opt(item).toString())
                }
                var validate: String? = preferences.getString("validate", null)
                if (validate.isNullOrBlank()) {
                    validate = preferences.getString(
                        "validate_list",
                        reference.get()?.getString(R.string.validate_default)
                    )
                }
                return NetRequestUtils.requestPostByForm(validate!!, formBody.build())
            } catch (e: Exception) {
                e.printStackTrace()
            }
            return null
        }

        override fun onPostExecute(s: String?) {
            if (reference.get() != null && s?.isNotBlank() == true) {
                Toast.makeText(reference.get(), s, Toast.LENGTH_SHORT).show()
            }
        }

    }

    override fun onDestroy() {
        super.onDestroy()
        gtCaptcha4Client?.destroy()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        gtCaptcha4Client?.configurationChanged(newConfig)
    }

    companion object {
        private const val TAG = "HomeFragment"
    }

    // 自行实现loading，需要和自定义loading资源路径区分开
    private fun isCustomImplLoading(): Boolean {
        val preferences = PreferenceManager.getDefaultSharedPreferences(context)
        return preferences.getBoolean("custom_impl_loading", resources.getBoolean(R.bool.custom_impl_loading_default))
    }

    private var customLoading: ProgressDialog? = null

    private fun showCustomLoading() {
        customLoading?.dismiss()
        customLoading = ProgressDialog.show(context, null, "验证加载中")
    }

    private fun dismissCustomLoading() {
        customLoading?.dismiss()
    }
}
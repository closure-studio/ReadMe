package com.geetest.captcha.demo

import android.app.Dialog
import android.content.Context
import android.os.Build
import android.util.Log
import android.view.View
import android.view.WindowManager
import androidx.preference.PreferenceManager
import com.geetest.captcha.GTCaptcha4Client
import com.geetest.captcha.GTCaptcha4Config
import com.geetest.captcha.demo.utils.Constants
import com.geetest.captcha.demo.utils.OtherUtils
//import com.geetest.captcha.utils.OtherUtils
import org.json.JSONArray
import org.json.JSONObject
import java.security.SecureRandom
import java.util.*

object CaptchaUtils {

    fun newGTCaptcha4Client(context: Context): GTCaptcha4Client {
        val preferences = PreferenceManager.getDefaultSharedPreferences(context)
        val hashMap = HashMap<String, Any>()
        // 本地加载中间页 loading 相对路径，如 ./loading.gif。注意：若远程加载不传此字段，默认不配置
        // load the middle page locally, loading the relative path, such as ./loading.gif. Note: If this field is not transmitted by remote loading, it is not configured by default
        // 若接入方要完全自行实现loading，需要设置 loading 为空。传无效路径前端会加载一个占位图片
        if (preferences.getBoolean("custom_impl_loading",
                context.resources.getBoolean(R.bool.custom_impl_loading_default))) {
            hashMap["loading"] = ""
        } else {
            val customLoadingPathInput = preferences.getString("custom_loading_path_input", null)
            if (customLoadingPathInput.isNullOrBlank()) { // 没有输入自定义loading路径文本，以自定义loading路径选择的为准来配置
                val customLoadingPathSelect = preferences.getString("custom_loading_path",
                    context.resources.getString(R.string.custom_loading_path_default))
                if ("-1" != customLoadingPathSelect) {
                    customLoadingPathSelect?.let {
                        hashMap["loading"] = it
                    }
                } // -1 是不设置
            } else { // 输入了自定义loading路径文本
                hashMap["loading"] = customLoadingPathInput
            }
        }
        Log.i(Constants.TAG, "loading:" + hashMap["loading"])
        hashMap["displayArea"] = preferences.getString("display", context.resources.getString(R.string.display_default))!!
        val displayMode = preferences.getString("style", context.resources.getString(R.string.style_default))!!.toInt()
        if (displayMode != -1) {
            hashMap["displayMode"] = displayMode
        }
        val color = preferences.getInt("background_color", context.resources.getInteger(R.integer.background_color_default))
        hashMap["bgColor"] = String.format("#%02x%02x%02x%02x", color, color, color, color)

        val debug = preferences.getBoolean("debug", context.resources.getBoolean(R.bool.debug_default))
        val logEnable = preferences.getBoolean("open_log", context.resources.getBoolean(R.bool.open_log_default))
        // 协议，https:// 或者 http://，默认 https://
        // protocol, https:// or http://, https:// by default
        if (debug) {
            hashMap["protocol"] = "http://"
        } else {
            hashMap["protocol"] = "https://"
        }
        // hashMap["resumeTimers"] = false
        hashMap["useLocalOffline"] = preferences.getBoolean("useLocalOffline", context.resources.getBoolean(R.bool.local_offline_default))
        val privatization = preferences.getBoolean("privatization", context.resources.getBoolean(R.bool.privatization_default))
        if (privatization) {
            // TODO 私有化版本添加额外数据，默认不配置
            // TODO Privatized version adds extra data, not configured by default
            hashMap["ext"] = JSONObject().apply {
                this.put("man", Build.MANUFACTURER)
                this.put("model", Build.MODEL)
                this.put("release", Build.VERSION.RELEASE)
                this.put("test1", SecureRandom().nextInt(100))
                this.put("test2", JSONObject().apply {
                    this.put("test3", SecureRandom().nextInt(100))
                    this.put("test4", SecureRandom().nextInt(100))
                })
            }
            val crypto: String? = preferences.getString(
                "crypto",
                context.resources.getString(R.string.crypto_default)
            )
            if(crypto?.isNotBlank() == true){
                hashMap["encryption"] = crypto
            }
        }
        // 配置风险类型，具体参考服务参数配置
        // Configure the risk type. For details, see the service documentation
        val riskType = preferences.getString("riskType", null)
        if (riskType?.isNotBlank() == true) {
            hashMap["riskType"] = riskType
        }
        val customKey = preferences.getString("customKey", null)
        val customValueStr = preferences.getString("customValue", null)
        val customValueBool = preferences.getBoolean("customValueBool", false)
        customKey?.takeIf {
            it.isNotBlank()
        }?.let {
            if (!customValueStr.isNullOrBlank()) {
                customValueStr.let { value ->
                    if (value.isNotBlank()) {
                        hashMap[customKey] =
                            if (customKey == "dbgColor" && value.startsWith("#") && value.length > 7) {
                                OtherUtils.hexToRgba(value)
                            } else {
                                value
                            }
                    }
                }
            } else {
                hashMap[it] = customValueBool
            }
        }


        // 配置是否隐藏成功 Loading
        // Configure whether to hide successful Loading
        val hideSuccess =
            preferences.getBoolean(
                "hideSuccess",
                context.resources.getBoolean(R.bool.hide_bind_success_default)
            )
        hashMap["hideSuccess"] = hideSuccess
        val language: String? = preferences.getString("language", context.resources.getString(R.string.language_default))
            .takeIf { it != "customize" } ?: preferences.getString("input_language", context.resources.getString(R.string.language_default))

        val builder = GTCaptcha4Config.Builder()
                // TODO 配置 debug 开关，线上版本务必关闭
                // TODO The debug switch, release version must be closed
                .setDebug(debug)
                // 语言配置，默认为应用语言
                // Language configuration, the default is the application language
                .setLanguage(language)
                // 超时配置，默认为 10s
                // Set the request timeout, default is 10s
                .setTimeOut(preferences.getInt("timeout", context.resources.getInteger(R.integer.timeout_default)))
                // 设置点击灰色区域是否消失，默认消失
                // Set whether the gray area disappears when clicking, and it disappears by default
                .setCanceledOnTouchOutside(preferences.getBoolean("outside", context.resources.getBoolean(R.bool.canceled_touch_outside)))
                // 额外参数配置，当前参数完全传输给 JS
                // Extra parameter configuration, the current parameter is completely transferred to JS
                .setParams(hashMap)

        // 配置自定义对话框的主题样式，用于移除蒙层
        val customDialogStyle =
            preferences.getBoolean(
                "custom_dialog_style",
                context.resources.getBoolean(R.bool.custom_dialog_style_default)
            )
        if (customDialogStyle) { // 去除对话框蒙层的自定义主题样式
            builder.setDialogStyle("demo_dialog_style")
        }

        var id: String? = preferences.getString("captcha_id", null)
        if (id.isNullOrBlank()) {
            id = preferences.getString("captcha_id_list", context.resources.getString(R.string.captcha_id_default))
        }

        val fullscreen =
            preferences.getBoolean(
                "fullscreen",
                context.resources.getBoolean(R.bool.fullscreen_default)
            )
        if (fullscreen) { // 去除对话框蒙层的自定义主题样式
            builder.setDialogShowListener(object : GTCaptcha4Client.OnDialogShowListener {
                override fun actionBeforeDialogShow(dialog: Dialog?) {
                    dialog!!.window!!.setFlags(
                        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                    )
                }

                override fun actionAfterDialogShow(dialog: Dialog?) {
                    val uiOptions = (View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                                or View.SYSTEM_UI_FLAG_FULLSCREEN)
                    dialog!!.window!!.decorView.systemUiVisibility = uiOptions
                    dialog.window!!.clearFlags(WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE)
                }

                override fun onDialogFocusChanged(dialog: Dialog?, hasFocus: Boolean) {
                }
            })
        }

        // TODO 私有化版本添加额外数据，默认不配置
        // TODO Privatized version adds extra data, not configured by default
        var apiServers: String? = preferences.getString("api_servers", null)
        if (apiServers.isNullOrBlank()) {
            apiServers = preferences.getString("api_servers_list", context.resources.getString(R.string.api_server_default))
        }
        apiServers?.let {
            if (it.isNotBlank()) {
//                val jsonArray = JSONArray()
//                it.split(',').forEach { api ->
//                    jsonArray.put(api.trim())
                    builder.setApiServers(it.split(',').toTypedArray())
//                }
//                hashMap["apiServers"] = jsonArray
            }
        }
        // TODO 私有化版本添加额外数据，默认不配置
        // TODO Privatized version adds extra data, not configured by default
        var staticServers: String? = preferences.getString("static_servers", null)
        if (staticServers.isNullOrBlank()) {
            staticServers = preferences.getString("static_servers_list", context.resources.getString(R.string.static_server_default))
        }
        staticServers?.let {
            if (it.isNotBlank()) {
//                val jsonArray = JSONArray()
//                it.split(',').forEach { api ->
//                    jsonArray.put(api.trim())
//                }
//                hashMap["staticServers"] = jsonArray
                builder.setStaticServers(it.split(',').toTypedArray())
            }
        }

        val client = GTCaptcha4Client.getClient(context)
        client.setLogEnable(logEnable)
        client.init(id!!, builder.build())
        return client
    }
}